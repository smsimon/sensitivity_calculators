#Set environment on a bash shell
PYTHONPATH=${PYTHONPATH}:$(pwd)/src